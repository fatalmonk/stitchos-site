# StitchOS - Weaving Intelligence Into Every Thread

## Overview

StitchOS is an AI-powered textile manufacturing intelligence platform that unites RFID, QR, and IoT technologies into a comprehensive production tracking and optimization system. The platform provides real-time visibility, predictive quality control, and compliance management for textile manufacturers, with a focus on the Bangladesh market.

The application is built as a full-stack web platform featuring a marketing website with contact form functionality, designed to showcase the platform's six core modules: Trace, Control, Ledger, Pack, Fabric, and Measure. The system emphasizes AI-driven insights, hybrid RFID/QR tracking capabilities, and EPCIS 2.0 compliance for global export readiness.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for type safety and modern development experience
- **Vite** as the build tool and development server for fast hot module replacement
- **Wouter** for client-side routing instead of React Router, providing a lightweight routing solution
- **TailwindCSS** for utility-first styling with a custom design system
- **Framer Motion** for smooth animations and page transitions
- **Shadcn/ui** component library built on Radix UI primitives for accessible, customizable components

### Backend Architecture
- **Express.js** server with TypeScript for API endpoints
- **In-memory storage** (MemStorage class) for development and testing, designed to be easily replaceable with database implementation
- **RESTful API** design with `/api/contact` endpoints for form submission and retrieval
- **Zod** for runtime validation and type safety across client/server boundaries

### Styling and Design System
- **Custom CSS variables** for theming with dark mode support
- **Brand gradient** defined as CSS custom property for consistent visual identity
- **Responsive design** with mobile-first approach using Tailwind breakpoints
- **Component-based architecture** with reusable UI components for cards, buttons, forms, etc.

### Form Handling and Validation
- **React Hook Form** for performant form management with minimal re-renders
- **Zod schemas** shared between client and server for consistent validation
- **Contact submission system** with fields for name, email, company, phone, message, and brochure request

### State Management and Data Fetching
- **TanStack Query (React Query)** for server state management, caching, and synchronization
- **Custom query client** configuration with error handling and credential management
- **Optimistic updates** and error boundaries for robust user experience

### Content Management
- **Static content files** in TypeScript modules for easy maintenance and type safety
- **Modular content structure** separating case studies, KPIs, modules, and process steps
- **SEO optimization** with meta tag generation utilities

### Database Schema Design
- **Drizzle ORM** with PostgreSQL dialect for type-safe database operations
- **UUID primary keys** with automatic generation
- **Contact submissions table** with timestamp tracking and optional fields
- **User authentication schema** prepared for future implementation

### Development and Build Process
- **TypeScript** for full-stack type safety
- **ESBuild** for fast production builds
- **Development/production environment** configuration with appropriate optimizations
- **Replit integration** with development banner and error modal support

### External Dependencies

- **Neon Database** (via @neondatabase/serverless) for PostgreSQL hosting
- **Drizzle** ecosystem for database ORM and migrations
- **Radix UI** primitives for accessible component foundation
- **Tailwind CSS** for utility-first styling
- **React ecosystem** including React Query, Hook Form, and Framer Motion
- **Express.js** for server runtime
- **Vite** for modern build tooling and development experience

The architecture is designed for scalability and maintainability, with clear separation of concerns between presentation, business logic, and data layers. The modular approach allows for easy extension of features and integration with external services as the platform grows.